const Jvtc = require('../bin/jvtc');

function Main() {
	const formdata = {
		loginName: "172052267", loginPwd: "172052267wx"
	}

	const jvtc = new Jvtc(formdata);

	jvtc.login().then(async ([err,stat]) => {
    if(err) {
      console.log(err);
      return err;
    }

		const userinfo = await jvtc.getUserinfo()
		console.log(userinfo);
		
		// jvtc_get("http://xz.jvtc.jx.cn/JVTC_XG/SystemForm/WorkInfo.aspx", jvtc.o, (error, res) => {
		// 	console.log(res.text);
		// });
		// jvtc_get("http://xz.jvtc.jx.cn/JVTC_XG/SystemForm/Class/MyStudent.aspx", jvtc.o, (error, res) => {
		// 	console.log(res.text);
		// });

	})
}

Main();